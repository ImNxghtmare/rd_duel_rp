#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

const int FLAG_MASK_DIR = 7;
const int FLAG_INSIDE_FACE = 1 << 4;
const int FLAG_USE_TOP_COLOR = 1 << 5;
const int FLAG_EXTRA_Z = 1 << 6;
const int FLAG_EXTRA_X = 1 << 7;

layout(std140) uniform CloudInfo {
vec4 CloudColor;
vec3 CloudOffset;
vec3 CellSize;
};

uniform isamplerBuffer CloudFaces;

out float vertexDistance;
out vec4 vertexColor;

const vec3[] vertices = vec3[](
vec3(1, 0, 0), vec3(1, 0, 1), vec3(0, 0, 1), vec3(0, 0, 0),
vec3(0, 1, 0), vec3(0, 1, 1), vec3(1, 1, 1), vec3(1, 1, 0),
vec3(0, 0, 0), vec3(0, 1, 0), vec3(1, 1, 0), vec3(1, 0, 0),
vec3(1, 0, 1), vec3(1, 1, 1), vec3(0, 1, 1), vec3(0, 0, 1),
vec3(0, 0, 1), vec3(0, 1, 1), vec3(0, 1, 0), vec3(0, 0, 0),
vec3(1, 0, 0), vec3(1, 1, 0), vec3(1, 1, 1), vec3(1, 0, 1)
);

const vec4[] faceColors = vec4[](
vec4(0.7, 0.7, 0.7, 1.0), vec4(1.0, 1.0, 1.0, 1.0), vec4(0.8, 0.8, 0.8, 1.0),
vec4(0.8, 0.8, 0.8, 1.0), vec4(0.9, 0.9, 0.9, 1.0), vec4(0.9, 0.9, 0.9, 1.0)
);

bool mcb_near(float v, float t) { return abs(v - t) < 0.0001; }
bool mcb_grid(float v) { return mcb_near(v, 0.0) || mcb_near(v, 0.5) || mcb_near(v, 1.0); }
float mcb_flag(float v) { return abs(fract(v * 16.0) - 0.375000) < 0.002 ? 1.0 : 0.0; }
// Seated cameras sit at a flagged fraction of a block along one horizontal axis and on the half-block
// grid on the other two: 0 for x, 2 for z. An overlay's camera is the player's own eye with all three
// flagged (each moved at most 1/32 of a block): 1. -1 when this camera is not seated.
int mcb_flag_axis() {
vec3 f = -CameraOffset;
if (mcb_flag(f.x) > 0.0 && mcb_flag(f.y) > 0.0 && mcb_flag(f.z) > 0.0) return 1;
if (!mcb_grid(f.y)) return -1;
if (mcb_grid(f.z) && mcb_flag(f.x) > 0.0) return 0;
if (mcb_grid(f.x) && mcb_flag(f.z) > 0.0) return 2;
return -1;
}
float mcb_seated_flag() { return mcb_flag_axis() >= 0 ? 1.0 : 0.0; }
// Only orthographic (GUI) draws: perspective projections have ProjMat[3][3] == 0.
float mcb_seated_now() { return ProjMat[3][3] != 1.0 ? 0.0 : mcb_seated_flag(); }
vec2 mcb_gui_size() { return vec2(2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1])); }
// Reversed depth (near 1, far 0) has ProjMat[2][2] near 0; OpenGL's classic has it near -1.
float mcb_reversed() { return ProjMat[2][2] > -0.5 ? 1.0 : 0.0; }

void main() {
int quadVertex = gl_VertexID % 4;
int index = (gl_VertexID / 4) * 3;
int cellX = texelFetch(CloudFaces, index).r;
int cellZ = texelFetch(CloudFaces, index + 1).r;
int dirAndFlags = texelFetch(CloudFaces, index + 2).r;
int direction = dirAndFlags & FLAG_MASK_DIR;
bool isInsideFace = (dirAndFlags & FLAG_INSIDE_FACE) == FLAG_INSIDE_FACE;
bool useTopColor = (dirAndFlags & FLAG_USE_TOP_COLOR) == FLAG_USE_TOP_COLOR;
cellX = (cellX << 1) | ((dirAndFlags & FLAG_EXTRA_X) >> 7);
cellZ = (cellZ << 1) | ((dirAndFlags & FLAG_EXTRA_Z) >> 6);
vec3 faceVertex = vertices[(direction * 4) + (isInsideFace ? 3 - quadVertex : quadVertex)];
vec3 pos = (faceVertex * CellSize) + (vec3(cellX, 0, cellZ) * CellSize) + CloudOffset;
gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
// An overlay's camera: outside the clip volume, so nothing is drawn.
if (mcb_flag_axis() == 1) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
vertexDistance = fog_spherical_distance(pos);
vertexColor = (useTopColor ? faceColors[1] : faceColors[direction]) * CloudColor;
}
