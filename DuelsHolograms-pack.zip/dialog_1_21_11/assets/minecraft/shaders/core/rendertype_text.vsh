#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    if (ProjMat[3][3] < 0.5) return;
    vec2 ndc = gl_Position.xy / gl_Position.w;
    float guiWidth = 2.0 / ProjMat[0][0];
    float guiHeight = -2.0 / ProjMat[1][1];
    // Font ascent carries explicit per-quad geometry. The 8192px lanes and
    // their midpoint padding absorb native bossbar row placement and float32
    // rounding; the metadata never depends on an assumed first-bar baseline.
    // Layout: height-1 (7 bits), absolute y/layer (10 bits).
    if (Position.y < 536870912.0 || Position.y >= 1610612736.0) return;
    int metadata=int(floor((Position.y-536870912.0)/8192.0));
    int row=metadata&1023;
    float height=float((metadata>>10)+1);
    int corner=gl_VertexID&3;
    bool bottom=corner==1||corner==2;
    bool pointer=row==1023;
    bool background=row>=512&&!pointer;
    vec2 logical=vec2(ndc.x*guiWidth*0.5+240.0,float(row&511)+(bottom ? height:0.0));
    if (pointer) {
        ivec3 rgb=ivec3(round(Color.rgb*255.0));
        int data=(rgb.r<<16)|(rgb.g<<8)|rgb.b;
        vec2 extent=vec2(corner>=2 ? 8.0:0.0,bottom ? height:0.0);
        logical=vec2(float(data&511),float((data>>9)&511))+extent;
        vertexColor=vec4(1.0);
    }
    float scale=min(1.25,min(guiWidth*0.90/480.0,guiHeight*0.986/416.0));
    vec2 screen=vec2(guiWidth*0.5+(logical.x-240.0)*scale,(guiHeight-416.0*scale)*0.5+logical.y*scale);
    if (background) {
        float cover=max(guiWidth/720.0,guiHeight/450.0);
        screen=vec2(guiWidth*0.5,guiHeight*0.5)+(logical-vec2(360.0,225.0))*cover;
    }
    gl_Position.xy=vec2(screen.x*2.0/guiWidth-1.0,1.0-screen.y*2.0/guiHeight)*gl_Position.w;
    sphericalVertexDistance=0.0;
    cylindricalVertexDistance=0.0;
}
