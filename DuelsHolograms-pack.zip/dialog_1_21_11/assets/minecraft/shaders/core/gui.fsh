#version 330

// Vanilla 1.21.11 startup shaders cannot use moj_import.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
noperspective in vec2 dialogPosition;
noperspective in vec2 dialogQuadUv;
flat in vec2 dialogScreenSize;

out vec4 fragColor;

bool same(float actual, float expected) {
    // Float derivative error at large GUI scales; neighboring integer GUI
    // positions and sizes still cannot match this subpixel tolerance.
    return abs(actual - expected) < 0.0625;
}

bool nativeBodyY(float y, float bodyHeight) {
    // Native multi-body lists position independent rows throughout the scroll area.
    // Only known centered widths/heights reach here; retain integer pixel geometry.
    return y >= -bodyHeight - 0.0625 && y <= dialogScreenSize.y + 0.0625
        && same(y, round(y));
}

bool selectorEdge(vec2 origin, vec2 size, vec2 bodySize) {
    float x = floor(max(0.0, dialogScreenSize.x - bodySize.x - 20.0) * 0.5) + 10.0;
    if (same(size.x, bodySize.x) && same(size.y, 1.0) && same(origin.x, x)) {
        return nativeBodyY(origin.y, bodySize.y)
            || nativeBodyY(origin.y - bodySize.y + 1.0, bodySize.y);
    }
    if (same(size.x, 1.0) && same(size.y, bodySize.y - 2.0)
            && (same(origin.x, x) || same(origin.x, x + bodySize.x - 1.0))) {
        return nativeBodyY(origin.y - 1.0, bodySize.y);
    }
    return false;
}

void main() {
    // Derivatives reconstruct this indexed quad's own origin and dimensions.
    // Compute before branching so helper fragments retain defined derivatives.
    mat2 uvDerivative = mat2(dFdx(dialogQuadUv), dFdy(dialogQuadUv));
    mat2 positionDerivative = mat2(dFdx(dialogPosition), dFdy(dialogPosition));
    bool hide = false;
    if (all(equal(vertexColor * ColorModulator, vec4(1.0))) && dialogScreenSize.x > 0.0
            && dialogScreenSize.y >= 38.0 && abs(determinant(uvDerivative)) > 1e-12) {
        mat2 axes = positionDerivative * inverse(uvDerivative);
        // Reject rotated/sheared primitives, ordinary fills and non-white UI.
        if (same(axes[0].y, 0.0) && same(axes[1].x, 0.0)) {
            vec2 size = vec2(axes[0].x, axes[1].y);
            vec2 origin = dialogPosition + vec2(dialogScreenSize.x * 0.5, 160.0) - axes * dialogQuadUv;
            // Match FocusableTextWidget's four edges for our two native layouts:
            // canvas 400x225 -> 410x233; canvas 336x189 -> 346x197.
            // Geometry is the only available identifier. An unrelated opaque
            // white outline with identical size and placement also matches.
            hide = selectorEdge(origin, size, vec2(346.0, 26.0))
                || selectorEdge(origin, size, vec2(346.0, 35.0))
                || selectorEdge(origin, size, vec2(346.0, 44.0))
                || selectorEdge(origin, size, vec2(346.0, 53.0))
                || selectorEdge(origin, size, vec2(346.0, 62.0))
                || selectorEdge(origin, size, vec2(346.0, 71.0))
                || selectorEdge(origin, size, vec2(346.0, 80.0))
                || selectorEdge(origin, size, vec2(346.0, 98.0))
                || selectorEdge(origin, size, vec2(346.0, 116.0))
                || selectorEdge(origin, size, vec2(346.0, 170.0))
                || selectorEdge(origin, size, vec2(346.0, 197.0))
                || selectorEdge(origin, size, vec2(346.0, 224.0))
                || selectorEdge(origin, size, vec2(346.0, 251.0))
                || selectorEdge(origin, size, vec2(410.0, 26.0))
                || selectorEdge(origin, size, vec2(410.0, 35.0))
                || selectorEdge(origin, size, vec2(410.0, 44.0))
                || selectorEdge(origin, size, vec2(410.0, 53.0))
                || selectorEdge(origin, size, vec2(410.0, 62.0))
                || selectorEdge(origin, size, vec2(410.0, 71.0))
                || selectorEdge(origin, size, vec2(410.0, 80.0))
                || selectorEdge(origin, size, vec2(410.0, 89.0))
                || selectorEdge(origin, size, vec2(410.0, 116.0))
                || selectorEdge(origin, size, vec2(410.0, 134.0))
                || selectorEdge(origin, size, vec2(410.0, 206.0))
                || selectorEdge(origin, size, vec2(410.0, 233.0))
                || selectorEdge(origin, size, vec2(410.0, 260.0))
                || selectorEdge(origin, size, vec2(410.0, 296.0));
        }
    }
    vec4 color = vertexColor;
    if (color.a == 0.0 || hide) {
        discard;
    }
    fragColor = color * ColorModulator;
}
